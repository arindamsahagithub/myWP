export class User {
    uid = '';
    uname = '';
    upass='';
    uaddress='';
}
